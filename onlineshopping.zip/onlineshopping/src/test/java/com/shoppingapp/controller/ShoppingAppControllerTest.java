package com.shoppingapp.controller;

import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.exceptions.InvalidRequestException;
import com.shoppingapp.exceptions.ProductNotFoundException;
import com.shoppingapp.exceptions.UserAlreadyExistsException;
import com.shoppingapp.model.Admin;
import com.shoppingapp.model.Product;
import com.shoppingapp.model.Response;
import com.shoppingapp.model.User;
import com.shoppingapp.service.implementation.AdminServiceImpl;
import com.shoppingapp.service.implementation.ProductServiceImpl;
import com.shoppingapp.service.implementation.UserServiceImpl;
import com.shoppingapp.service.interfaces.IAdminService;
import com.shoppingapp.service.interfaces.IProductService;
import com.shoppingapp.service.interfaces.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.apache.commons.lang.StringUtils;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.mockito.Mockito.mock;

class ShoppingAppControllerTest {

    private IAdminService adminService;
    private IProductService productService;
    private IUserService userService;
    private ShoppingAppController shoppingAppController;
    private Admin admin;
    private User user;
    private Product product;
    private List<Product> productList;
    private Response response;
    private Response productResponse;

    private static final String PRODUCT_NAME = "Sunsilk";
    private static final String EMPTY_STRING = StringUtils.EMPTY;

    @BeforeEach
    public void init() {
        shoppingAppController = new ShoppingAppController();
        adminService = mock(AdminServiceImpl.class);
        productService = mock(ProductServiceImpl.class);
        userService = mock(UserServiceImpl.class);
        admin = mock(Admin.class);
        product = mock(Product.class);
        user = mock(User.class);
        ReflectionTestUtils.setField(shoppingAppController,"adminService",adminService);
        ReflectionTestUtils.setField(shoppingAppController,"userService",userService);
        ReflectionTestUtils.setField(shoppingAppController,"productService",productService);
    }

    @Test
    void testRegister() throws InvalidRequestException, UserAlreadyExistsException {
        Mockito.when(userService.registerUser(user)).thenReturn(response);
        Response actualResponse = shoppingAppController.register(user);
        assertEquals(response, actualResponse);
    }

    @Test
    void testRegisterNull() throws UserAlreadyExistsException {
        Mockito.when(userService.registerUser(user)).thenThrow(InvalidRequestException.class);
        assertThrows(InvalidRequestException.class, () -> {
            shoppingAppController.register(null);
        });

    }

    @Test
    void testUserLogin() throws InvalidRequestException, InvalidCredentialException {
        Mockito.when(userService.userLogin(user)).thenReturn(response);
        Response actualResponse = shoppingAppController.userLogin(user);
        assertEquals(response, actualResponse);

    }

    @Test
    void testUserLoginNull() throws InvalidCredentialException {
        Mockito.when(userService.userLogin(user)).thenThrow(InvalidRequestException.class);
        assertThrows(InvalidRequestException.class, () -> {
            shoppingAppController.register(null);
        });
    }

    @Test
    void testAdminLogin() throws InvalidRequestException, InvalidCredentialException {
        Mockito.when(adminService.adminLogin(admin)).thenReturn(response);
        Response actualResponse = shoppingAppController.adminLogin(admin);
        assertEquals(response, actualResponse);
    }

    @Test
    void testAdminLoginNull() throws InvalidCredentialException {
        Mockito.when(adminService.adminLogin(admin)).thenThrow(InvalidRequestException.class);
        assertThrows(InvalidRequestException.class, () -> {
            shoppingAppController.adminLogin(admin);
        });
    }

    @Test
    void testAddProduct() throws InvalidRequestException{
        Mockito.when(productService.addProduct(product)).thenReturn(response);
        Response actualResponse = shoppingAppController.addProduct(product);
        assertEquals(response, actualResponse);
    }

    @Test
    void testAddProductNull(){
        Mockito.when(productService.addProduct(product)).thenThrow(InvalidRequestException.class);
        assertThrows(InvalidRequestException.class, () -> {
            shoppingAppController.addProduct(null);
        });
    }

    @Test
    void testDeleteProduct() throws InvalidRequestException, ProductNotFoundException {
        Mockito.when(productService.deleteProduct(PRODUCT_NAME)).thenReturn(productResponse);
        Response actualResponse = shoppingAppController.deleteProduct(PRODUCT_NAME);
        assertEquals(response, actualResponse);
    }

    @Test
    void testDeleteProductNull() throws  ProductNotFoundException {
        Mockito.when(productService.deleteProduct(PRODUCT_NAME)).thenThrow(InvalidRequestException.class);
        assertThrows(InvalidRequestException.class, () -> {
            shoppingAppController.deleteProduct(EMPTY_STRING);
        });
    }
}