package com.shoppingapp.service.implementation;

import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.model.Admin;
import com.shoppingapp.model.Response;
import com.shoppingapp.persistence.IAdminRepo;
import com.shoppingapp.service.interfaces.IAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements IAdminService {

    @Autowired
    IAdminRepo adminRepo;

    @Override
    public Response adminLogin(Admin admin) throws InvalidCredentialException {
        Response adminResponse = new Response();
        Admin admin1 = adminRepo.findAdminByLoginId(admin.getLoginId());
        if (admin1 != null) {
            if (admin1.getPassword().equals(admin.getPassword())) {
                adminResponse.setAck("0");
                adminResponse.setMessage("Login Successful.");
                return adminResponse;
            } else {
                throw new InvalidCredentialException();
            }
        }
        else {
            throw new InvalidCredentialException();
        }
    }
}
