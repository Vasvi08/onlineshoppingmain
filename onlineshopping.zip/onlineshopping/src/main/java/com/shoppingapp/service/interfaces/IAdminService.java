package com.shoppingapp.service.interfaces;

import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.model.Response;
import org.springframework.stereotype.Service;

@Service
public interface IAdminService {
    public Response adminLogin(String loginId, String password) throws InvalidCredentialException;

}
