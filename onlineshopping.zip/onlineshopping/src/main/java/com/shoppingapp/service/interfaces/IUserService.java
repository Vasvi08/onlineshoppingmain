package com.shoppingapp.service.interfaces;

import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.exceptions.UserAlreadyExistsException;
import com.shoppingapp.model.Response;
import com.shoppingapp.model.UserModel;
import org.springframework.stereotype.Service;

@Service
public interface IUserService {
    public Response registerUser(UserModel userModel) throws UserAlreadyExistsException;
    public Response userLogin(String loginId, String password) throws InvalidCredentialException;
}
