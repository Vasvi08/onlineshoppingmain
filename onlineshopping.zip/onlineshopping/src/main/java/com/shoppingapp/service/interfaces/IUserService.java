package com.shoppingapp.service.interfaces;

import com.shoppingapp.model.UserModel;
import org.springframework.stereotype.Service;

@Service
public interface IUserService {
    public UserModel registerUser(UserModel userModel);
}
