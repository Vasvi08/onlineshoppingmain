package com.shoppingapp.service.interfaces;

import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.exceptions.UserAlreadyExistsException;
import com.shoppingapp.model.Response;
import com.shoppingapp.model.User;
import org.springframework.stereotype.Service;

@Service
public interface IUserService {
    public Response registerUser(User userModel) throws UserAlreadyExistsException;
    public Response userLogin(User userModel) throws InvalidCredentialException;
}
