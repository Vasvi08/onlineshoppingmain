package com.shoppingapp.service.interfaces;

import com.shoppingapp.exceptions.ProductNotFoundException;
import com.shoppingapp.model.Product;
import com.shoppingapp.model.Response;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IProductService {
    public Response addProduct(Product product);
    public List<Product> getProducts();
    public Product getProductByName(String productName) throws ProductNotFoundException;
    public Response updateProductStatus(String productName, Product product) throws ProductNotFoundException;
    public Response deleteProduct(String productName) throws ProductNotFoundException;
    public Response placeOrder(String loginId, Product product);
}

