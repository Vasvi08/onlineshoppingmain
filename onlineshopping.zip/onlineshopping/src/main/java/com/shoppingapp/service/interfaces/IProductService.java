package com.shoppingapp.service.interfaces;

import com.shoppingapp.model.Product;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IProductService {
    public Product addProduct(Product product);
    public List<Product> getProducts();
    public Product getProductByName(String productName);
    public Product updateProductStatus(String productName, Product product);
    public Product deleteProduct(String productName);
}

