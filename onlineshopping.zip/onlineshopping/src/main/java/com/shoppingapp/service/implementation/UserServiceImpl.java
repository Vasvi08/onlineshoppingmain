package com.shoppingapp.service.implementation;

import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.exceptions.UserAlreadyExistsException;
import com.shoppingapp.model.Response;
import com.shoppingapp.model.User;
import com.shoppingapp.persistence.IUserRepo;
import com.shoppingapp.service.interfaces.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    IUserRepo userRepo;

    @Override
    public Response registerUser(User user) throws UserAlreadyExistsException {
        String loginId = user.getLoginId();
        String email = user.getEmail();
        User userModel1 = userRepo.findUserByLoginId(loginId);
        User userModel2 = userRepo.findUserByEmail(email);
        if(userModel1 == null && userModel2 == null) {
            Response registrationResponse = new Response();
            userRepo.save(user);
            registrationResponse.setAck("0");
            registrationResponse.setMessage("Registered Successfully");
            return registrationResponse;
        }
        else {
            throw new UserAlreadyExistsException();
        }
    }

    @Override
    public Response userLogin(User user) throws InvalidCredentialException {
        Response userResponse = new Response();
        User userModel = userRepo.findUserByLoginId(user.getLoginId());
        if (userModel != null) {
            if (user.getPassword().equals(userModel.getPassword())) {
                userResponse.setAck("0");
                userResponse.setMessage("Login Successful.");
                return userResponse;
            } else {
                throw new InvalidCredentialException();
            }
        }
        else {
            throw new InvalidCredentialException();
        }
    }

    @Override
    public Response forgetPassword(User user) throws InvalidCredentialException {
        Response forgetPasswordResponse = new Response();
        User userModel = userRepo.findUserByLoginId(user.getLoginId());
        userRepo.deleteByLoginId(user.getLoginId());
        if(userModel != null && user.getEmail().equals(userModel.getEmail())){
            userModel.setPassword(user.getPassword());
            userRepo.save(userModel);
            forgetPasswordResponse.setAck("0");
            forgetPasswordResponse.setMessage("Password updated successfully");
            return forgetPasswordResponse;
        }
        else{
            throw new InvalidCredentialException();
        }

    }

}
