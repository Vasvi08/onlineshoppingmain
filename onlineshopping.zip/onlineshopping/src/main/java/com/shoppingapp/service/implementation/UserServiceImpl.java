package com.shoppingapp.service.implementation;

import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.exceptions.UserAlreadyExistsException;
import com.shoppingapp.model.Response;
import com.shoppingapp.model.User;
import com.shoppingapp.persistence.IUserRepo;
import com.shoppingapp.service.interfaces.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    IUserRepo userRepo;

    @Override
    public Response registerUser(User userModel) throws UserAlreadyExistsException {
        String loginId = userModel.getLoginId();
        String email = userModel.getEmail();
        User userModel1 = userRepo.findUserByLoginId(loginId);
        User userModel2 = userRepo.findUserByEmail(email);
        if(userModel1 == null && userModel2 == null) {
            Response registrationResponse = new Response();
            userRepo.save(userModel);
            registrationResponse.setAck("0");
            registrationResponse.setMessage("Registered Successfully");
            return registrationResponse;
        }
        else {
            throw new UserAlreadyExistsException();
        }
    }

    @Override
    public Response userLogin(User userModel) throws InvalidCredentialException {
        Response userResponse = new Response();
        User userModel1 = userRepo.findUserByLoginId(userModel.getLoginId());
        if (userModel1 != null) {
            if (userModel.getPassword().equals(userModel1.getPassword())) {
                userResponse.setAck("0");
                userResponse.setMessage("Login Successful.");
                return userResponse;
            } else {
                throw new InvalidCredentialException();
            }
        }
        else {
            throw new InvalidCredentialException();
        }
    }

}
