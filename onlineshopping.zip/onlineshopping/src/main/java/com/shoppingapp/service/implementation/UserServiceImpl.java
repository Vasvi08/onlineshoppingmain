package com.shoppingapp.service.implementation;

import com.shoppingapp.model.UserModel;
import com.shoppingapp.persistence.IUserRepo;
import com.shoppingapp.service.interfaces.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService {

    @Autowired
    IUserRepo userRepo;

    @Override
    public UserModel registerUser(UserModel userModel) {
        userRepo.save(userModel);
        return userModel ;
    }
}
