package com.shoppingapp.service.implementation;

import com.shoppingapp.exceptions.ProductNotFoundException;
import com.shoppingapp.model.Order;
import com.shoppingapp.model.Product;
import com.shoppingapp.model.Response;
import com.shoppingapp.persistence.IOrderRepo;
import com.shoppingapp.persistence.IProductDataAccess;
import com.shoppingapp.persistence.IProductRepo;
import com.shoppingapp.service.interfaces.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {

    @Autowired
    IProductRepo productRepo;

    @Autowired
    IOrderRepo orderRepo;

    @Autowired
    IProductDataAccess productDataAccess;

    @Override
    public Response addProduct(Product product) {
        Response productResponse = new Response();
        productRepo.save(product);
        productResponse.setAck("0");
        productResponse.setMessage("Product added successfully.");
        return productResponse;
    }

    @Override
    public List<Product> getProducts() {
        return productRepo.findAll();
    }

    @Override
    public Product getProductByName(String productName) throws ProductNotFoundException {
        Product product = productRepo.findProductByProductName(productName);
        if(product == null){
            throw new ProductNotFoundException();
        }
        else{
            return product;
        }
    }

    @Override
    public Response updateProductStatus(String productName, String productStatus) throws ProductNotFoundException {
        Response productResponse = new Response();
        Product product1 = productRepo.findProductByProductName(productName);
        if(product1 == null){
            throw new ProductNotFoundException();
        }
        else {
            productDataAccess.updateProductStatus(productName, productStatus);
            productResponse.setAck("0");
            productResponse.setMessage("Product status updated successfully.");
            return productResponse;
        }
    }

    @Override
    public Response deleteProduct(String productName) throws ProductNotFoundException{
        Response productResponse = new Response();
        Product product1 = productRepo.findProductByProductName(productName);
        if(product1 == null){
            throw new ProductNotFoundException();
        }
        else {
            productRepo.deleteByProductName(productName);
            productResponse.setAck("0");
            productResponse.setMessage("Product deleted successfully.");
            return productResponse;
        }
    }

    @Override
    public Response placeOrder(String loginId, Product product) {
        Response addToCartResponse = new Response();
            Order userOrder = new Order();
            userOrder.setLoginId(loginId);
            userOrder.setProduct(product);
            Long timeStamp = getTimeStamp();
            userOrder.setTimeStamp(timeStamp);
            orderRepo.save(userOrder);
            quantity(product);
            Product product1 = productRepo.findProductByProductName(product.getProductName());
            if(product1.getQuantity() < 1){
                productDataAccess.updateProductStatus(product.getProductName(), "Out of stock");
            }
            else {
                productDataAccess.updateProductStatus(product.getProductName(), "Hurry up to purchase");
            }
            addToCartResponse.setAck("0");
            addToCartResponse.setMessage("Product added successfully");
            return addToCartResponse;
    }

    @Override
    public List<Order> getOrders() {
        return orderRepo.findAll();
    }

    public void quantity(Product product){
        Product product1 = productRepo.findProductByProductName(product.getProductName());
        productRepo.deleteByProductName(product.getProductName());
        product1.setQuantity(product1.getQuantity()-1);
        productRepo.save(product1);
    }

    public Long getTimeStamp() {
        return OffsetDateTime.now(ZoneOffset.UTC).toInstant().toEpochMilli();
    }

}
