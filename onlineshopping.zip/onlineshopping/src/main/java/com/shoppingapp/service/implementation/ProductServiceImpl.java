package com.shoppingapp.service.implementation;

import com.shoppingapp.model.Product;
import com.shoppingapp.persistence.IProductRepo;
import com.shoppingapp.service.interfaces.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {

    @Autowired
    IProductRepo productRepo;

    @Override
    public Product addProduct(Product product) {
        productRepo.save(product);
        return product;
    }

    @Override
    public List<Product> getProducts() {
        return productRepo.findAll();
    }

    @Override
    public Product getProductByName(String productName) {
        return productRepo.findProductByProductName(productName);
    }

    @Override
    public Product updateProductStatus(String productName, Product product) {
        return productRepo.save(product);
    }

    @Override
    public Product deleteProduct(String productName) {
        return productRepo.deleteByProductName(productName);
    }


}
