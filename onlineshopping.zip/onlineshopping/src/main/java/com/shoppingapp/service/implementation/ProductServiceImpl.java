package com.shoppingapp.service.implementation;

import com.shoppingapp.exceptions.ProductNotFoundException;
import com.shoppingapp.model.Product;
import com.shoppingapp.model.Response;
import com.shoppingapp.persistence.IProductRepo;
import com.shoppingapp.service.interfaces.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {

    @Autowired
    IProductRepo productRepo;

    @Override
    public Response addProduct(Product product) {
        Response productResponse = new Response();
        productRepo.save(product);
        productResponse.setAck("0");
        productResponse.setMessage("Product added successfully.");
        return productResponse;
    }

    @Override
    public List<Product> getProducts() {
        return productRepo.findAll();
    }

    @Override
    public Product getProductByName(String productName) throws ProductNotFoundException {
        Product product = productRepo.findProductByProductName(productName);
        if(product == null){
            throw new ProductNotFoundException();
        }
        else{
            return product;
        }
    }

    @Override
    public Response updateProductStatus(String productName, Product product) throws ProductNotFoundException {
        Response productResponse = new Response();
        Product product1 = productRepo.findProductByProductName(productName);
        if(product1 == null){
            throw new ProductNotFoundException();
        }
        else {
            productRepo.save(product);
            productResponse.setAck("0");
            productResponse.setMessage("Product status updated successfully.");
            return productResponse;
        }
    }

    @Override
    public Response deleteProduct(String productName) throws ProductNotFoundException{
        Response productResponse = new Response();
        Product product1 = productRepo.findProductByProductName(productName);
        if(product1 == null){
            throw new ProductNotFoundException();
        }
        else {
            productRepo.deleteByProductName(productName);
            productResponse.setAck("0");
            productResponse.setMessage("Product deleted successfully.");
            return productResponse;
        }
    }


}
