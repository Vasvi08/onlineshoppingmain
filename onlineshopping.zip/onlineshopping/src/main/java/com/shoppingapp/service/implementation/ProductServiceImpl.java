package com.shoppingapp.service.implementation;

import com.shoppingapp.exceptions.ProductNotFoundException;
import com.shoppingapp.model.Order;
import com.shoppingapp.model.Product;
import com.shoppingapp.model.Response;
import com.shoppingapp.persistence.IOrderRepo;
import com.shoppingapp.persistence.IProductRepo;
import com.shoppingapp.service.interfaces.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {

    @Autowired
    IProductRepo productRepo;

    @Autowired
    IOrderRepo orderRepo;

    @Override
    public Response addProduct(Product product) {
        Response productResponse = new Response();
        productRepo.save(product);
        productResponse.setAck("0");
        productResponse.setMessage("Product added successfully.");
        return productResponse;
    }

    @Override
    public List<Product> getProducts() {
        return productRepo.findAll();
    }

    @Override
    public Product getProductByName(String productName) throws ProductNotFoundException {
        Product product = productRepo.findProductByProductName(productName);
        if(product == null){
            throw new ProductNotFoundException();
        }
        else{
            return product;
        }
    }

    @Override
    public Response updateProductStatus(String productName, Product product) throws ProductNotFoundException {
        Response productResponse = new Response();
        Product product1 = productRepo.findProductByProductName(productName);
        if(product1 == null){
            throw new ProductNotFoundException();
        }
        else {
            productRepo.save(product);
            productResponse.setAck("0");
            productResponse.setMessage("Product status updated successfully.");
            return productResponse;
        }
    }

    @Override
    public Response deleteProduct(String productName) throws ProductNotFoundException{
        Response productResponse = new Response();
        Product product1 = productRepo.findProductByProductName(productName);
        if(product1 == null){
            throw new ProductNotFoundException();
        }
        else {
            productRepo.deleteByProductName(productName);
            productResponse.setAck("0");
            productResponse.setMessage("Product deleted successfully.");
            return productResponse;
        }
    }

    @Override
    public Response placeOrder(String loginId, Product product) {
        Order userOrder = orderRepo.findUserByLoginId(loginId);
        Response addToCartResponse = new Response();
        if(userOrder != null){
            List<Product> list = userOrder.getProduct();
            list.add(product);
            orderRepo.deleteByLoginId(loginId);
            Order userOrder1 = new Order();
            userOrder1.setLoginId(loginId);
            userOrder1.setProduct(list);
            orderRepo.save(userOrder1);
            addToCartResponse.setAck("0");
            addToCartResponse.setMessage("Product added successfully");
            return addToCartResponse;
        }
        else{
            Order userOrder1 = new Order();
            List<Product> list = null;
            list.add(product);
            userOrder1.setLoginId(loginId);
            userOrder1.setProduct(list);
            orderRepo.save(userOrder1);
            addToCartResponse.setAck("0");
            addToCartResponse.setMessage("Product added successfully");
            return addToCartResponse;
        }
    }


}
