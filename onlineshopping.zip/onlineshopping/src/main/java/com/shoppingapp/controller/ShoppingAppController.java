package com.shoppingapp.controller;


import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.exceptions.InvalidRequestException;
import com.shoppingapp.exceptions.ProductNotFoundException;
import com.shoppingapp.exceptions.UserAlreadyExistsException;
import com.shoppingapp.model.Admin;
import com.shoppingapp.model.Product;
import com.shoppingapp.model.Response;
import com.shoppingapp.model.User;
import com.shoppingapp.service.interfaces.IAdminService;
import com.shoppingapp.service.interfaces.IProductService;
import com.shoppingapp.service.interfaces.IUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ShoppingAppController {
    @Autowired
    IUserService userService;

    @Autowired
    IProductService productService;

    @Autowired
    IAdminService adminService;

    @PostMapping(value = "/register")
    public Response register(@RequestBody User user) throws InvalidRequestException, UserAlreadyExistsException {
        if(user != null) {
            Response response;
            response = userService.registerUser(user);
            log.info("User registration successful");
            return response;
        }
        else{
            throw new InvalidRequestException();
        }
    }

    @GetMapping(value = "/userLogin")
    public Response userLogin(@RequestBody User user) throws InvalidRequestException, InvalidCredentialException {
        if(user == null){
            throw new InvalidRequestException();
        }
        else {
            Response userResponse;
            userResponse = userService.userLogin(user);
            log.info("User Login successful");
            return userResponse;
        }
    }

    @PutMapping(value = "/forgetPassword")
    public Response forgetPassword(@RequestBody User user) throws InvalidRequestException, InvalidCredentialException {
        if(user != null) {
            Response forgetPasswordResponse;
            forgetPasswordResponse = userService.forgetPassword(user);
            log.info("Password updation successful");
            return forgetPasswordResponse;
        }
        else {
            throw new InvalidRequestException();
        }
    }

    @GetMapping(value = "/adminLogin")
    public Response adminLogin(@RequestBody Admin admin) throws InvalidRequestException, InvalidCredentialException {
        if(admin == null){
            throw new InvalidRequestException();
        }
        else {
            Response adminResponse;
            adminResponse = adminService.adminLogin(admin);
            log.info("Admin Login successful");
            return adminResponse;
        }
    }

    @PostMapping(value = "/addProduct")
    public Response addProduct(@RequestBody Product product) throws InvalidRequestException{
        if(product != null) {
            Response productResponse;
            log.info("Add Product successful");
            productResponse = productService.addProduct(product);
            return productResponse;
        }
        else {
            throw new InvalidRequestException();
        }
    }

    @GetMapping(value = "/getProducts")
    public ResponseEntity<List<Product>> getProducts() {
        List<Product> list = productService.getProducts();
        log.info("Get products successful");
        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    @GetMapping(value = "/getProductByName")
    public ResponseEntity<Product> getProductByName(@RequestParam String productName) throws InvalidRequestException, ProductNotFoundException {
        if(productName.isEmpty()){
            throw new InvalidRequestException();
        }
        else {
            Product product = productService.getProductByName(productName);
            log.info("Get products ny name successful");
            return new ResponseEntity<>(product, HttpStatus.OK);
        }
    }

    @PutMapping(value = "/updateProductStatus")
    public Response updateProductStatus(@RequestParam String productName, @RequestBody Product product) throws InvalidRequestException, ProductNotFoundException{
        if(productName.isEmpty() || product == null){
            throw new InvalidRequestException();
        }
        else {
            Response productResponse;
            productResponse = productService.updateProductStatus(productName, product);
            log.info("Update product status successful");
            return productResponse;
        }
    }

    @DeleteMapping(value = "/deleteProductByName")
    public Response deleteProduct(@RequestParam String productName) throws InvalidRequestException, ProductNotFoundException{
        if(productName.isEmpty()){
            throw new InvalidRequestException();
        }
        else {
            Response productResponse;
            productResponse = productService.deleteProduct(productName);
            log.info("Delete product successful");
            return productResponse;
        }
    }
}
