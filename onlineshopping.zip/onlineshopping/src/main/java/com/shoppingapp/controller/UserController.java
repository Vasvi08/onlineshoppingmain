package com.shoppingapp.controller;


import com.shoppingapp.model.Product;
import com.shoppingapp.model.UserModel;
import com.shoppingapp.persistence.IProductRepo;
import com.shoppingapp.service.interfaces.IProductService;
import com.shoppingapp.service.interfaces.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class UserController {
    @Autowired
    IUserService userService;

    @Autowired
    IProductService productService;

    @PostMapping(value = "/register")
    public ResponseEntity<UserModel> register(@RequestBody UserModel userModel){
        UserModel user = userService.registerUser(userModel);
       return new ResponseEntity<>(user, HttpStatus.OK);
    }

    @PostMapping(value = "/addProduct")
    public  ResponseEntity<Product> addProduct(@RequestBody Product product){
        Product product1 = productService.addProduct(product);
        return new ResponseEntity<>(product1, HttpStatus.OK);
    }

    @GetMapping(value = "/getProducts")
    public ResponseEntity<List<Product>> getProducts() {
        List<Product> list = productService.getProducts();
        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    @GetMapping(value = "/getProductByName")
    public ResponseEntity<Product> getProductByName(@RequestParam String productName){
        Product product = productService.getProductByName(productName);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }

    @PutMapping(value = "/updateProductStatus")
    public ResponseEntity<Product> updateProductStatus(@RequestParam String productName, @RequestBody Product product){
        Product product1 = productService.updateProductStatus(productName, product);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }

    @DeleteMapping(value = "/deleteProductByName")
    public ResponseEntity<Product> deleteProduct(@RequestParam String productName) {
        Product product = productService.deleteProduct(productName);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }


}
