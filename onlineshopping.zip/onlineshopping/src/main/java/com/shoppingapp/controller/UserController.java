package com.shoppingapp.controller;


import com.shoppingapp.exceptions.InvalidCredentialException;
import com.shoppingapp.exceptions.InvalidRequestException;
import com.shoppingapp.exceptions.ProductNotFoundException;
import com.shoppingapp.exceptions.UserAlreadyExistsException;
import com.shoppingapp.model.Product;
import com.shoppingapp.model.Response;
import com.shoppingapp.model.UserModel;
import com.shoppingapp.service.interfaces.IAdminService;
import com.shoppingapp.service.interfaces.IProductService;
import com.shoppingapp.service.interfaces.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class UserController {
    @Autowired
    IUserService userService;

    @Autowired
    IProductService productService;

    @Autowired
    IAdminService adminService;

    @PostMapping(value = "/register")
    public Response register(@RequestBody UserModel userModel) throws InvalidRequestException, UserAlreadyExistsException {
        if(userModel != null) {
            Response response = new Response();
            response = userService.registerUser(userModel);
            return response;
        }
        else{
            throw new InvalidRequestException();
        }
    }

    @GetMapping(value = "/userLogin")
    public Response userLogin(@RequestHeader String loginId, @RequestHeader String password) throws InvalidRequestException, InvalidCredentialException {
        if(loginId.isEmpty() || password.isEmpty()){
            throw new InvalidRequestException();
        }
        else {
            Response userResponse;
            userResponse = userService.userLogin(loginId, password);
            return userResponse;
        }
    }

    @GetMapping(value = "/adminLogin")
    public Response adminLogin(@RequestHeader String loginId, @RequestHeader String password) throws InvalidRequestException, InvalidCredentialException {
        if(loginId.isEmpty() || password.isEmpty()){
            throw new InvalidRequestException();
        }
        else {
            Response adminResponse;
            adminResponse = adminService.adminLogin(loginId, password);
            return adminResponse;
        }
    }

    @PostMapping(value = "/addProduct")
    public Response addProduct(@RequestBody Product product) throws InvalidRequestException{
        if(product != null) {
            Response productResponse;
            productResponse = productService.addProduct(product);
            return productResponse;
        }
        else {
            throw new InvalidRequestException();
        }
    }

    @GetMapping(value = "/getProducts")
    public ResponseEntity<List<Product>> getProducts() {
        List<Product> list = productService.getProducts();
        return new ResponseEntity<>(list, HttpStatus.OK);

    }

    @GetMapping(value = "/getProductByName")
    public ResponseEntity<Product> getProductByName(@RequestParam String productName) throws InvalidRequestException, ProductNotFoundException {
        if(productName.isEmpty()){
            throw new InvalidRequestException();
        }
        else {
            Product product = productService.getProductByName(productName);
            return new ResponseEntity<>(product, HttpStatus.OK);
        }
    }

    @PutMapping(value = "/updateProductStatus")
    public Response updateProductStatus(@RequestParam String productName, @RequestBody Product product) throws InvalidRequestException, ProductNotFoundException{
        if(productName.isEmpty() || product == null){
            throw new InvalidRequestException();
        }
        else {
            Response productResponse;
            productResponse = productService.updateProductStatus(productName, product);
            return productResponse;
        }
    }

    @DeleteMapping(value = "/deleteProductByName")
    public Response deleteProduct(@RequestParam String productName) throws InvalidRequestException, ProductNotFoundException{
        if(productName.isEmpty()){
            throw new InvalidRequestException();
        }
        else {
            Response productResponse;
            productResponse = productService.deleteProduct(productName);
            return productResponse;
        }
    }




}
