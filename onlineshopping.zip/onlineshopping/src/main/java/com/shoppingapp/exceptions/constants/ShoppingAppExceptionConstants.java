package com.shoppingapp.exceptions.constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public enum ShoppingAppExceptionConstants {
    DATABASE_EXCEPTION("","","4004","Database_Connection_Error"),
    PRODUCT_NOT_FOUND("", "Product is not present", "4004", "Product not supported"),
    INVALID_CREDENTIAL("","Invalid credentials","4004","Credentials not supported"),
    INVALID_REQUEST("1", "Invalid request", "4000", "Malformed request"),
    USER_ALREADY_EXISTS("","User already exists. Try signing in.","4004","User already exists");
    private String ack;
    private String message;
    private String code;
    private String category;
}
