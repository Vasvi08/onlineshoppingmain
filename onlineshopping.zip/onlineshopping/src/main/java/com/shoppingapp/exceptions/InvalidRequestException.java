package com.shoppingapp.exceptions;

import org.springframework.stereotype.Component;

@Component
public class InvalidRequestException extends Exception{
}
