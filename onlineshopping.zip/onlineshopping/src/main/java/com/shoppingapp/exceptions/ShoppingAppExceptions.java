package com.shoppingapp.exceptions;

import com.mongodb.MongoSocketOpenException;
import com.shoppingapp.exceptions.constants.ShoppingAppExceptionConstants;
import com.shoppingapp.model.ShoppingAppExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class ShoppingAppExceptions {

    @ExceptionHandler(MongoSocketOpenException.class)
    public ResponseEntity<ShoppingAppExceptionResponse> mongoSocketOpenExceptionHandler(Exception ex, WebRequest request) {
        ShoppingAppExceptionResponse error = ShoppingAppExceptionResponse.builder()
                .ack(ShoppingAppExceptionConstants.DATABASE_EXCEPTION.getAck())
                .category(ShoppingAppExceptionConstants.DATABASE_EXCEPTION.getCategory())
                .code(ShoppingAppExceptionConstants.DATABASE_EXCEPTION.getCode())
                .message(ShoppingAppExceptionConstants.DATABASE_EXCEPTION.getMessage())
                .build();
        return new ResponseEntity<>(error, HttpStatus.OK);
    }

    @ExceptionHandler(ProductNotFoundException.class)
    public ResponseEntity<ShoppingAppExceptionResponse> productNotFoundExceptionHandler(Exception ex, WebRequest request) {
        ShoppingAppExceptionResponse error = ShoppingAppExceptionResponse.builder()
                .ack(ShoppingAppExceptionConstants.PRODUCT_NOT_FOUND.getAck())
                .category(ShoppingAppExceptionConstants.PRODUCT_NOT_FOUND.getCategory())
                .code(ShoppingAppExceptionConstants.PRODUCT_NOT_FOUND.getCode())
                .message(ShoppingAppExceptionConstants.PRODUCT_NOT_FOUND.getMessage())
                .build();
        return new ResponseEntity<>(error, HttpStatus.OK);
    }

    @ExceptionHandler(InvalidCredentialException.class)
    public ResponseEntity<ShoppingAppExceptionResponse> invalidCredentialExceptionHandler(Exception ex, WebRequest request) {
        ShoppingAppExceptionResponse error = ShoppingAppExceptionResponse.builder()
                .ack(ShoppingAppExceptionConstants.INVALID_CREDENTIAL.getAck())
                .category(ShoppingAppExceptionConstants.INVALID_CREDENTIAL.getCategory())
                .code(ShoppingAppExceptionConstants.INVALID_CREDENTIAL.getCode())
                .message(ShoppingAppExceptionConstants.INVALID_CREDENTIAL.getMessage())
                .build();
        return new ResponseEntity<>(error, HttpStatus.OK);
    }

    @ExceptionHandler({InvalidRequestException.class, HttpMessageNotReadableException.class,
            MissingRequestHeaderException.class, MissingServletRequestParameterException.class})
    public ResponseEntity<ShoppingAppExceptionResponse> invalidRequestExceptionHandler(Exception ex, WebRequest request) {
        ShoppingAppExceptionResponse error = ShoppingAppExceptionResponse.builder()
                .ack(ShoppingAppExceptionConstants.INVALID_REQUEST.getAck())
                .category(ShoppingAppExceptionConstants.INVALID_REQUEST.getCategory())
                .code(ShoppingAppExceptionConstants.INVALID_REQUEST.getCode())
                .message(ShoppingAppExceptionConstants.INVALID_REQUEST.getMessage())
                .build();
        return new ResponseEntity<>(error, HttpStatus.OK);
    }

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<ShoppingAppExceptionResponse> userAlreadyExistsExceptionHandler(Exception ex, WebRequest request) {
        ShoppingAppExceptionResponse error = ShoppingAppExceptionResponse.builder()
                .ack(ShoppingAppExceptionConstants.USER_ALREADY_EXISTS.getAck())
                .category(ShoppingAppExceptionConstants.USER_ALREADY_EXISTS.getCategory())
                .code(ShoppingAppExceptionConstants.USER_ALREADY_EXISTS.getCode())
                .message(ShoppingAppExceptionConstants.USER_ALREADY_EXISTS.getMessage())
                .build();
        return new ResponseEntity<>(error, HttpStatus.OK);
    }

}
