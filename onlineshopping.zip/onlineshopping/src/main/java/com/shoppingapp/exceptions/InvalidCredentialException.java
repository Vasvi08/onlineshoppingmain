package com.shoppingapp.exceptions;

import org.springframework.stereotype.Component;

@Component
public class InvalidCredentialException extends Exception{
}
