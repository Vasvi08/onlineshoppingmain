package com.shoppingapp.exceptions;

import org.springframework.stereotype.Component;

@Component
public class UserAlreadyExistsException extends Exception{
}
