package com.shoppingapp.persistence;

import com.shoppingapp.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IProductRepo extends MongoRepository<Product, String> {
    Product findProductByProductName(String productName);
    Product deleteByProductName(String productName);
}
