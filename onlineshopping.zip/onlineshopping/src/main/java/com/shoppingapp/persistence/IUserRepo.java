package com.shoppingapp.persistence;


import com.shoppingapp.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IUserRepo extends MongoRepository<User, String> {
    User findUserByLoginId(String loginId);
    User findUserByEmail(String userId);
    User deleteByLoginId(String loginId);
}
