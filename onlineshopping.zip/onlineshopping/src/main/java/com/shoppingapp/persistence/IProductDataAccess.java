package com.shoppingapp.persistence;

import org.springframework.stereotype.Repository;

@Repository
public interface IProductDataAccess {

    void updateProductStatus(String productName, String productStatus);
}
