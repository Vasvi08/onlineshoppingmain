package com.shoppingapp.persistence;

import com.shoppingapp.model.Order;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IOrderRepo extends MongoRepository<Order, String> {
    Order findUserByLoginId(String loginId);
    Order deleteByLoginId(String loginId);
}
