package com.shoppingapp.persistence;

import com.shoppingapp.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;

@Document(collection = "product")
@Repository
public class ProductDataAccess implements IProductDataAccess{

    private static final String PRODUCT_NAME = "productName";
    private static final String PRODUCT_STATUS = "productStatus";
    @Autowired
    private MongoTemplate mongoTemplate;
    @Override
    public void updateProductStatus(String productName, String productStatus) {
        Query query = new Query();
        query.addCriteria(where(PRODUCT_NAME).is(productName));
        Update update = new Update();
        update.set(PRODUCT_STATUS, productStatus);
        mongoTemplate.updateMulti(query, update, Product.class);
    }
}
