package com.shoppingapp.persistence;

import com.shoppingapp.model.Admin;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IAdminRepo extends MongoRepository<Admin, String> {
    Admin findAdminByLoginId(String loginId);
}
